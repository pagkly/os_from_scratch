**WARNING! Thanos showed up out of nowhere and nuked most of the extension.**

Actually no, it was just me doing what I do best; horrible big version transition that upsets almost everyone... again.
First and foremost I am sorry that I upset so many of you, but please understand I am under limited time, this isn't something I can dedicate as much time as I could before and for that reason this migration is everything but smooth.

With that said, let's get down to it:

 - First read this: https://github.com/ParticleCore/Iridium/tree/1.0.0
 - Userscripts depended on a CSS file that was hosted in GitHub, with that gone the UI for the userscript version is now gone.
   - A solution for this could be to use the extension version still available in Chrome and AMO
 - The Firefox extension can be reverted if users would rather wait for the new version to be more mature, just head to the history list and choose the version you like: https://addons.mozilla.org/firefox/addon/particle-iridium/versions/

Again, I am sorry for everyone that is upset with this abrupt transition, if I could've done it in any other way that would not require more time that I don't have I would've.

Do remember: This was created to improve my experience on YouTube and shared to improve yours, there is no obligation. You should always find anything that helps make your experience better, if this extension no longer helps with that then finding another that does is not only a suggestion but a must!


# Iridium [![current version](https://img.shields.io/github/release/ParticleCore/Iridium/all.svg)](https://github.com/ParticleCore/Iridium/releases/latest)

**[Download](https://github.com/ParticleCore/Iridium/wiki/Download) | [Features](https://github.com/ParticleCore/Iridium/wiki/Features) | [Report a problem](https://github.com/ParticleCore/Iridium/wiki/Report-a-bug) | [Donate](https://github.com/ParticleCore/Iridium/wiki/Donate)**

Iridium (former [YouTube Plus](https://github.com/ParticleCore/Particle)) is an extension built to improve the user experience on the new YouTube Material layout.  

**Before opening a new issue [read the rules](https://github.com/ParticleCore/Iridium/blob/master/CONTRIBUTING.md).**

Current bug support is being provided only for:  

[![Firefox 57+](https://img.shields.io/badge/Firefox-57%2B-orange.svg)](https://www.mozilla.org/firefox)  

## Mentions

Find out what others had to say about Iridium; the good and the bad!  

--- 
## ghacks.net · [Iridium gives you more control on YouTube](https://www.ghacks.net/2018/06/08/iridium-gives-you-more-control-on-youtube/)  

--- 
  
  
### [Iridium - Extenda as funções do seu Youtube!](https://www.youtube.com/watch?v=SloSxxlFlOA)
[<img src="https://i.ytimg.com/vi/SloSxxlFlOA/maxresdefault.jpg" width="50%">](https://www.youtube.com/watch?v=SloSxxlFlOA)  
  
---  

### [Une nouvelle EXTENSION que j'utilise AU QUOTIDIEN !](https://www.youtube.com/watch?v=aCsJz59XJ3M)
[<img src="https://i.ytimg.com/vi/aCsJz59XJ3M/maxresdefault.jpg" width="50%">](https://www.youtube.com/watch?v=aCsJz59XJ3M)
  
---  

### [CET OUTIL RÉVOLUTIONNE YOUTUBE !](https://www.youtube.com/watch?v=PYA-oWG5WGw)
[<img src="https://i.ytimg.com/vi/PYA-oWG5WGw/maxresdefault.jpg" width="50%">](https://www.youtube.com/watch?v=PYA-oWG5WGw)

