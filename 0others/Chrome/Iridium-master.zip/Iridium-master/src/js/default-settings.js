window.defaultSettings = {
    iridiumLogo: true,
    syncSettings: false,
    quickControls: true,
    darkTheme: true,
    autoPlayVideo: false,
    maxResThumbnail: true,
    hfrOn: true
};