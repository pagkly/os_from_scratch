Contact for permissions other than the use of the software and its contents for non-comercial
personal purposes, such as, and not limited to:

 - Use of the software for its intended purpose
 - Use of the source code for learning and teaching purposes
 - Use of the software and its source code for sharing without unauthorized third party modifications
   with included easily visible linkbacks directing to the source of the original file(s) location(s) or main directory
